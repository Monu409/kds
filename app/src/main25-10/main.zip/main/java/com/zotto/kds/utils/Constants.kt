package com.zotto.kds.utils

class Constants {

}