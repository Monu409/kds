package com.zotto.kds.model

data class OnlineProducts(
    val status: Int,
    val results: List<Data>,
)