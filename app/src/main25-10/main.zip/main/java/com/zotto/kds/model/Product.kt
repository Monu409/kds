package com.zotto.kds.model

class Product {
    var name:String?=null
    var quantity:String?=null

    override fun toString(): String {
        return "Product(name=$name, quantity=$quantity)"
    }


}