package com.zotto.kds.database.m_table

data class RootProductModel(
    val `data`: List<Data>,
    val status: Int
)