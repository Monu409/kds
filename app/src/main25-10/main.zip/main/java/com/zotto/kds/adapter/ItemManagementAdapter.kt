package com.zotto.kds.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.DiffUtil.ItemCallback
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.zotto.kds.R
import com.zotto.kds.database.dao.DisabledCategoryDao
import com.zotto.kds.database.table.CategoryTable
import com.zotto.kds.database.table.DisabledTable
import com.zotto.kds.localIP.SendTask
import com.zotto.kds.restapi.ApiServices
import com.zotto.kds.ui.ProductByCatActivity
import com.zotto.kds.ui.main.MainActivity
import com.zotto.kds.utils.SessionManager
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import org.json.JSONObject

class ItemManagementAdapter(
    val restId: String,
    val context: Context,
    val disabledProductDao: DisabledCategoryDao?,
    var apiServices: ApiServices,
) : ListAdapter<Any, RecyclerView.ViewHolder>(DiffUtil()) {
    val VIEW_TYPE_ITEM = 1
    val VIEW_TYPE_HEADER = 0

    class DiffUtil : ItemCallback<Any>() {
        override fun areItemsTheSame(oldItem: Any, newItem: Any): Boolean {
            if (oldItem is CategoryTable && newItem is CategoryTable)
                return oldItem.category_id == newItem.category_id
            else return oldItem.equals(newItem)
        }

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: Any, newItem: Any): Boolean {
            return oldItem == newItem
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        var view: View?
        if (viewType == VIEW_TYPE_ITEM) {
            view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_management_row, parent, false)
            return MyViewHolder(view)
        } else if (viewType == VIEW_TYPE_HEADER) {
            view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_management_header, parent, false)
            return HeaderViewHolder(view)
        }
        throw RuntimeException("There is no type that matches the type $viewType. Make sure you are using view types correctly!");

    }

    override fun getItemViewType(position: Int): Int {
        if (getItem(position) is String)
            return VIEW_TYPE_HEADER
        else
            return VIEW_TYPE_ITEM

    }

    class HeaderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var header = itemView.findViewById<TextView>(R.id.header)
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        var product_name = itemView.findViewById<TextView>(R.id.product_name)
        var quantity = itemView.findViewById<TextView>(R.id.quantity)
        var btn_parent = itemView.findViewById<LinearLayout>(R.id.btn_parent)
        var enable_btn = itemView.findViewById<RelativeLayout>(R.id.enable_btn)
        var disable_btn = itemView.findViewById<RelativeLayout>(R.id.disable_btn)
        var enable_txt = itemView.findViewById<TextView>(R.id.enable_txt)
        var disable_txt = itemView.findViewById<TextView>(R.id.disable_txt)
        var modifiersname = itemView.findViewById<TextView>(R.id.modifiers)
        var topping_name = itemView.findViewById<TextView>(R.id.topping_name)
        var full_row = itemView.findViewById<ConstraintLayout>(R.id.full_row)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        var item = getItem(position)
        if (holder is HeaderViewHolder) {
            Log.e("categoryName=", item.toString())
            holder.header.text = item.toString()
        } else if (holder is MyViewHolder) {
            var cat_item: CategoryTable = item as CategoryTable
//            var product: Product = item as Product
            holder.product_name.text = cat_item.cname

            setUpButton(holder, cat_item)
            holder.full_row.setOnClickListener {
                val intent = Intent(context, ProductByCatActivity::class.java)
                intent.putExtra("Username", "John Doe")
                intent.putExtra("cat_id", cat_item.category_id)
                context.startActivity(intent)
                MainActivity.refreshFragment = true
                if (disabledProductDao!!.isCategoryIsExist(restId, cat_item.category_id!!)) {
                    disabledProductDao.deleteDisabledCategory(restId, cat_item.category_id!!)
                }
                else {
                    var disPr = DisabledTable()
                    disPr.restaurant_id = restId
                    disPr.category_id = cat_item.category_id
                    disPr.status = 0
                    disPr.type = cat_item.type
                    disabledProductDao.insertDisabledCategory(disPr)
                    var availableKey = if(holder.enable_txt.text=="Available"){
                        "0"
                    } else{
                        "1"
                    }
                    val compositeDisposable = CompositeDisposable()
                    val rootObject= JSONObject()
                    rootObject.put("product_id",cat_item.category_id)
                    rootObject.put("restaurant_id",SessionManager.getRestaurantId(context))
                    rootObject.put("product_status",availableKey)
                    if(SessionManager.getSelectedPort(context)?.isEmpty() != true){
                        rootObject.put("type","OnlineProductStockUpdate")
                        var orderPort = SessionManager.getSelectedPort(context)?.toInt()
                        var orderIp = SessionManager.getSelectedIp(context)
                        val sendTask = SendTask(context, rootObject.toString(), orderIp, orderPort!!)
                        sendTask.execute()
                    }


                    compositeDisposable.add(
                        apiServices.updateItem(
                            SessionManager.getToken(context),
                            rootObject.toString()
                        ).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io())
                            .subscribe({ response -> (response) },
                                { t -> (t) })
                    )
                }
                notifyItemChanged(position)
            }

        }
    }

    private fun setUpButton(holder: MyViewHolder, product: CategoryTable) {
        if (disabledProductDao!!.isCategoryIsExist(restId, product.category_id!!)) {
//            holder.disable_btn.background = ContextCompat.getDrawable(
//                context,
//                R.drawable.rectangular_right_roundshape_red
//            )
            holder.enable_txt.text = "Available"
//            holder.enable_btn.background = null
//            holder.disable_txt.setTextColor(Color.parseColor("#FFFFFF"))
//            holder.enable_txt.setTextColor(Color.parseColor("#666171"))

        } else {
//            holder.enable_btn.background = ContextCompat.getDrawable(
//                context,
//                R.drawable.rectangular_left_roundshape_green
//            )
            holder.enable_txt.text = "Not Available"
//            holder.disable_btn.background = null
//            holder.enable_txt.setTextColor(Color.parseColor("#FFFFFF"))
//            holder.disable_txt.setTextColor(Color.parseColor("#666171"))
        }

    }

}