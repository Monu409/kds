package com.zotto.kds.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.zotto.kds.R
import com.zotto.kds.database.table.Product
import com.zotto.kds.model.Summary
import java.lang.Exception

class SummaryAdapter(var header:String, val productList: List<Summary>, val context: Context) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    val VIEW_TYPE_ITEM = 1
    val VIEW_TYPE_HEADER = 0
    var fmname=""
    var omname=""
    var toppingname=""
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        var view : View?=null
        if (viewType == VIEW_TYPE_ITEM) {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.summary_row, parent, false)
            return MyViewHolder(view)
        }else if (viewType == VIEW_TYPE_HEADER) {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.summary_header, parent, false)
            return HeaderViewHolder(view)
        }
        throw  RuntimeException("There is no type that matches the type " + viewType + ". Make sure you are using view types correctly!");
    }

    override fun getItemCount(): Int {
        if (productList != null && productList.size == 0){
            return 1
        }else{
            return productList.size+1
        }
    }

    override fun getItemViewType(position: Int): Int {
        if (isPositionHeader(position))
            return VIEW_TYPE_HEADER
        else
            return VIEW_TYPE_ITEM

    }
    fun isPositionHeader(position: Int):Boolean{
        if (position == 0){
            return true
        }else{
            return false
        }

    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, @SuppressLint("RecyclerView") position: Int) {

        if (holder is HeaderViewHolder) {
            Log.e("categoryName=",header!!)
            (holder as HeaderViewHolder).header.text=header!!
        }else if (holder is MyViewHolder){
            var product=productList.get(position-1)
            (holder as MyViewHolder).product_name.text=product.name
            (holder as MyViewHolder).quantity.text=product.quantity.toString()
            Log.e("quantity=",product.quantity!!.toString())
             fmname=""
             omname=""
             toppingname=""
            try {
                Log.e("fm=",product.toString()+"--"+product.fmname!!+"-om-"+product.omname!!+"-toppingname-"+product.toppingname!!)
                  if (!product.fmname!!.isNullOrEmpty()){
                      if (product.fmname!!.contains("\n")){
                          var fmarr=product.fmname!!.split("\n")
                          for (i in 0 until fmarr.size){
                              if (fmname!!.isNullOrEmpty()){
                                  fmname=fmarr.get(i)
                              }else{
                                  fmname=fmname+"\n"+fmarr.get(i)
                              }
                          }
                      }else{
                          fmname=product.fmname!!
                      }
                  }
                if (!product.omname!!.isNullOrEmpty()){
                    if (product.omname!!.contains("\n")){
                        var omarr=product.omname!!.split("\n")
                        for (i in 0 until omarr.size){
                            if (omname!!.isNullOrEmpty()){
                                omname=omarr.get(i)
                            }else{
                                omname=omname+"\n"+omarr.get(i)
                            }
                        }
                    }else{
                        omname=product.omname!!
                    }
                }
                if (!product.toppingname!!.isNullOrEmpty()){
                    if (product.toppingname!!.contains("\n")){
                        var toppingarr=product.toppingname!!.split("\n")
                        for (i in 0 until toppingarr.size){
                            if (toppingname!!.isNullOrEmpty()){
                                toppingname=toppingarr.get(i)
                            }else{
                                toppingname=toppingname+"\n"+toppingarr.get(i)
                            }
                        }
                    }else{
                        toppingname=product.toppingname!!
                    }
                }
                if (!fmname.isNullOrEmpty() && !omname.isNullOrEmpty()){
                    (holder as MyViewHolder).modifiersname.visibility=View.VISIBLE
                    (holder as MyViewHolder).modifiersname.text=fmname+"\n"+omname
                }else{
                    if (fmname.isNullOrEmpty() && omname.isNullOrEmpty()){
                        (holder as MyViewHolder).modifiersname.visibility=View.GONE
                    }else{
                        (holder as MyViewHolder).modifiersname.visibility=View.VISIBLE
                        (holder as MyViewHolder).modifiersname.text=fmname+"\n"+omname
                    }

                }
                if (!toppingname.isNullOrEmpty()){
                    (holder as MyViewHolder).topping_name.visibility=View.VISIBLE
                    (holder as MyViewHolder).topping_name.text=toppingname
                }else{
                    (holder as MyViewHolder).topping_name.visibility=View.GONE
                }

            }catch (e: Exception){
                e.printStackTrace()
            }catch (e:NullPointerException){
                e.printStackTrace()
            }
        }
    }
    class HeaderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var header= itemView.findViewById<TextView>(R.id.header)
    }
    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        var product_name= itemView.findViewById<TextView>(R.id.product_name)
        var quantity=itemView.findViewById<TextView>(R.id.quantity)
        var modifiersname=itemView.findViewById<TextView>(R.id.modifiers)
        var topping_name=itemView.findViewById<TextView>(R.id.topping_name)
    }

}