package com.zotto.kds.repository

import android.content.Context

class SettingRepository(var context: Context) {
}