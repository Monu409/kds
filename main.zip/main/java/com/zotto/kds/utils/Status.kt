package com.zotto.kds.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}